import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import Link from "next/link"

export default function OfficeRunnerLanding() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Header */}
      <header className="bg-slate-800 text-white py-16 px-5 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">The Office Runner</h1>
        <p className="text-xl mb-8">Train Smart. Run Fast. Stay Sane.</p>
        <Link
          href="#get-started"
          className="inline-block bg-orange-600 hover:bg-orange-700 text-white font-bold py-4 px-8 rounded-md text-lg transition-colors"
        >
          Start Your Free Week
        </Link>
      </header>

      {/* Who It's For Section */}
      <section className="max-w-4xl mx-auto bg-white rounded-lg p-10 mt-5 mx-5">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Who It's For</h2>
        <p className="text-gray-700 mb-6">
          You're a busy professional with limited time, a stressful workload, and a desire to stay fit without flipping
          your life upside down. Welcome to your tribe.
        </p>
        <ul className="list-disc pl-6 text-gray-700 space-y-2">
          <li>Time-poor desk workers</li>
          <li>Remote workers needing structure</li>
          <li>Ambitious beginners training for 5K/10K</li>
        </ul>
      </section>

      {/* What You Get Section */}
      <section className="max-w-4xl mx-auto bg-white rounded-lg p-10 mt-5 mx-5">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">What You Get</h2>
        <ul className="list-disc pl-6 text-gray-700 space-y-2">
          <li>Weekly running plans tailored to your schedule</li>
          <li>10–30 minute strength and mobility sessions</li>
          <li>Email or SMS accountability check-ins</li>
          <li>Form coaching through video review</li>
          <li>Access to our private community</li>
        </ul>
      </section>

      {/* Pricing Plans Section */}
      <section className="max-w-4xl mx-auto bg-white rounded-lg p-10 mt-5 mx-5">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Pricing Plans</h2>
        <div className="space-y-4">
          <p className="text-gray-700">
            <strong>Free Kickstart:</strong> 5-day sample plan + newsletter + community invite
          </p>
          <p className="text-gray-700">
            <strong>Premium Plan:</strong> $29/month for customised coaching, accountability check-ins, and video
            feedback
          </p>
        </div>
      </section>

      {/* Get Started Section */}
      <section id="get-started" className="max-w-4xl mx-auto bg-white rounded-lg p-10 mt-5 mx-5">
        <h2 className="text-2xl font-bold text-slate-800 mb-4">Ready to Get Moving?</h2>
        <p className="text-gray-700 mb-6">
          Join hundreds of desk-bound pros who made the shift from "too busy" to "race-ready." You've got 5 minutes to
          sign up—and that's all you need.
        </p>

        <form action="https://formspree.io/f/xqabalwz" method="POST" className="space-y-4">
          <Input type="text" name="name" placeholder="Your Name" required className="w-full max-w-md" />
          <Input type="email" name="email" placeholder="Email Address" required className="w-full max-w-md" />
          <Button type="submit" className="w-full max-w-md bg-orange-600 hover:bg-orange-700 text-white font-bold py-3">
            Claim My Free Week
          </Button>
        </form>
      </section>

      {/* Footer */}
      <footer className="text-center py-8 text-sm text-gray-600">
        &copy; 2025 The Office Runner. All rights reserved.
      </footer>
    </div>
  )
}
